# Scientific references for the unscored review

These are complete shared source tables, not newly measured experimental results.
The six scientific assets recorded in the batch protocol are byte-checked against that runtime manifest.
The two supplementary report-annotation tables are copied from the matching source checkout; their hashes are recorded separately.
OligoFormer scores and seed matches are imported historical official outputs; no new heavy inference is claimed.
The expression table is untreated ARPE-19 baseline (one culture run; four vessels per oxygen state), not siRNA perturbation evidence.

The cloud archive excludes repeated seed_matches.tsv and seed_expression_details.tsv to avoid many duplicate large tables.
The complete underlying seed and expression source tables are supplied here once, with provenance and hashes.
Actual tool summaries, inputs and original answers for each answer_id remain in that answer's evidence.json.
These reference files are for checking evidence; they were NOT supplied as computed results to the no-tool model.
This package contains no group key, configuration, credentials, reviewer identity or filled scores.
