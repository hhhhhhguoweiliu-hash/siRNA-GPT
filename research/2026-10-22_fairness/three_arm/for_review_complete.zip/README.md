# 独立评审材料（未评分）

先读complete_tasks.json中的完整原始/解析输入和逐题要求，再读rubric.json及field_guide.json。
blind_answers.tsv与answers/保留原始回答，不做改写；对应input.json和evidence.json供核对。
填写blank_scores.tsv，保留评审编号和具体依据；空白不是0分。不要按工具数、COMPLETE或回复长度评分。
shared_resources.json说明资源与模型设置：普通模型无科学工具，两个工具条件共享科学数据；固定流程预选路径，Agent多轮，总预算不等同。
不向评审提供上一层private_key.tsv或完整运行原包。当前只移除组别标记，风格和证据可暴露配置，不能承诺完全盲法。
可用性/系统失败与科学质量分开；不可评分写原因，失败仍保留。六题为已见开发题，不是独立正式测试。
