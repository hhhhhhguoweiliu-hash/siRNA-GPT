from pathlib import Path
import sys,gzip,json,re,urllib.parse,hashlib
from collections import defaultdict
import pandas as pd
R=Path(__file__).resolve().parent;sys.path.append(str(R/'pydeps'))
from Bio import SeqIO
P=R/'public_sources';REF=R/'reference';O=R/'prepared';O.mkdir(exist_ok=True)
manifest=json.loads((REF/'reference_download_manifest.json').read_text())
assert all(x.get('official_md5_match') is True for x in manifest if x['filename'].endswith('.gz'))
records=list(SeqIO.parse(P/'VEGFA_vendor_versions.gb','genbank'))
baseline=R.parent.parent/'deliverables/ARPE19_baseline_20261016_v0.1/03_baseline'
vmap=pd.read_csv(baseline/'transcript_gene_map_vendor.tsv',sep='\t')
expected=vmap.loc[vmap.source_gene_id.eq('VEGFA'),'transcript_id'].tolist()
assert len(records)==len(expected)==len(set(r.id for r in records))
assert set(r.id for r in records)==set(expected)
assert all(r.annotations.get('organism')=='Homo sapiens' and any(f.type=='gene' and f.qualifiers.get('gene')==['VEGFA'] for f in r.features) for r in records)
SeqIO.write(records,O/'VEGFA_vendor_versions.fasta','fasta')
rows=[]
for rec in records:
 cds=[f for f in rec.features if f.type=='CDS']
 rows.append(dict(transcript_id=rec.id,length=len(rec),description=rec.description,cds_intervals=';'.join(str(f.location) for f in cds),sha256=hashlib.sha256(str(rec.seq).encode()).hexdigest(),sequence_status='EXACT_VENDOR_ACCESSION_VERSION_VERIFIED'))
pd.DataFrame(rows).to_csv(O/'VEGFA_transcript_manifest.tsv',sep='\t',index=False)
from zipfile import ZipFile
with ZipFile(r'C:\00000\ARPE RNA-seq\result\result.zip') as z:
 name=next(n for n in z.namelist() if n.endswith('6_expression/expression/transcript_tpm.xls'))
 with z.open(name) as f:tx=pd.read_csv(f,sep='\t',index_col=0)
tx.index.name='transcript_id';tx.to_csv(O/'vendor_transcript_tpm.tsv',sep='\t')
subset=tx.loc[expected].copy();subset['N_mean']=subset[['Nor'+str(i) for i in range(1,5)]].mean(axis=1);subset['H_mean']=subset[['Hyp'+str(i) for i in range(1,5)]].mean(axis=1)
subset['N_fraction_within_VEGFA']=subset.N_mean/subset.N_mean.sum();subset['H_fraction_within_VEGFA']=subset.H_mean/subset.H_mean.sum()
subset.sort_values('H_mean',ascending=False).to_csv(O/'VEGFA_transcript_TPM.tsv',sep='\t')
print('target transcript versions verified',len(records),flush=True)
print(subset[['N_mean','H_mean','N_fraction_within_VEGFA','H_fraction_within_VEGFA']].sort_values('H_mean',ascending=False).head(8).to_string(),flush=True)
rna={};exons=defaultdict(list);cds=defaultdict(list)
def attrs(s):return {k:urllib.parse.unquote(v) for k,v in (part.split('=',1) for part in s.split(';') if '=' in part)}
with gzip.open(REF/'GCF_000001405.40_GRCh38.p14_genomic.gff.gz','rt') as f:
 for line in f:
  if line.startswith('#'):continue
  a=line.rstrip('\n').split('\t')
  if len(a)!=9:continue
  chrom,src,kind,start,end,_,strand,_,astr=a
  if not re.match(r'^NC_0000(?:0[1-9]|1[0-9]|2[0-4])\.',chrom) and chrom!='NC_012920.1':continue
  at=attrs(astr)
  if kind in ('mRNA','transcript','lnc_RNA','ncRNA','rRNA','tRNA','snRNA','snoRNA','antisense_RNA','primary_transcript'):
   tid=at.get('transcript_id',at.get('Name',''))
   gid=re.search(r'GeneID:(\d+)',at.get('Dbxref',''))
   if tid.startswith(('NM_','XM_','NR_','XR_')):rna[at['ID']]=dict(transcript_id=tid,gene_id=gid.group(1) if gid else 'NA',symbol=at.get('gene',at.get('Name','NA')),chrom=chrom,strand=strand,start=int(start),end=int(end),annotation_partial=at.get('partial','false'))
  elif kind in ('exon','CDS'):
   for parent in at.get('Parent','').split(','):
    (exons if kind=='exon' else cds)[parent].append((int(start),int(end)))
print('primary RNA feature records',len(rna),flush=True)
rna_by_tx=defaultdict(list)
for rid,ann in rna.items():rna_by_tx[ann['transcript_id']].append((rid,ann))
allrows=[];utr_rows=[]
with gzip.open(REF/'GCF_000001405.40_GRCh38.p14_rna.fna.gz','rt') as f,open(O/'refseq_primary_transcripts.fasta','w') as whole,open(O/'refseq_all_transcripts.fasta','w') as allfa,open(O/'refseq_utr3_all.fasta','w') as utrfa:
 for rec in SeqIO.parse(f,'fasta'):
  seq=str(rec.seq).upper(); allfa.write(f'>{rec.id}\n{seq}\n')
  matches=rna_by_tx.get(rec.id,[])
  if len(matches)!=1:continue
  rid,a=matches[0];a=dict(a);a['transcript_length']=len(seq);a['utr_status']='UNKNOWN_NO_CDS'
  whole.write(f'>{rec.id}\n{seq}\n')
  if rec.id.startswith(('NM_','XM_')) and cds.get(rid):
   ee=sorted(set(exons[rid]),reverse=a['strand']=='-');length=sum(e-s+1 for s,e in ee)
   if length!=len(seq):a['utr_status']='UNKNOWN_ALIGNMENT_LENGTH_MISMATCH'
   elif a['annotation_partial']=='true':a['utr_status']='UNKNOWN_PARTIAL_RNA_ANNOTATION'
   else:
    projected=[];offset=0
    for s,e in ee:
     for cs,ce in cds[rid]:
      lo=max(s,cs);hi=min(e,ce)
      if lo<=hi:
       projected.append(offset+(hi-s+1 if a['strand']=='+' else e-lo+1))
     offset+=e-s+1
    if projected:
     end=max(projected);utr=seq[end:]
     if len(utr)>=8 and set(utr)<=set('ACGT'):
      a.update(utr_start_1based=end+1,utr_end_1based=len(seq),utr_length=len(utr),utr_status='ANNOTATED_CDS_PROJECTED_TO_MATCHING_LENGTH_REFSEQ_RNA')
      utr_rows.append(a);utrfa.write(f'>{rec.id}\n{utr}\n')
     else:a['utr_status']='UNKNOWN_SHORT_OR_AMBIGUOUS_UTR'
  allrows.append(a)
pd.DataFrame(allrows).to_csv(O/'refseq_primary_annotation.tsv',sep='\t',index=False)
u=pd.DataFrame(utr_rows);u.to_csv(O/'utr_manifest_all.tsv',sep='\t',index=False)
# Working representative: curated NM preferred, longest 3UTR, ties lexical accession. This is a reference sensitivity choice, not a measured dominant isoform.
u['curated_preference']=u.transcript_id.str.startswith('NM_').astype(int)
representatives=u.sort_values(['gene_id','curated_preference','utr_length','transcript_id'],ascending=[True,False,False,True]).drop_duplicates('gene_id').copy()
representatives['representative_rule']='WORKING_NM_PREFERRED_LONGEST_UTR_THEN_ACCESSION';representatives.to_csv(O/'utr_manifest_representative.tsv',sep='\t',index=False)
keep=set(representatives.transcript_id)
with open(O/'refseq_utr3_representative.fasta','w') as out:
 for rec in SeqIO.parse(O/'refseq_utr3_all.fasta','fasta'):
  if rec.id in keep:SeqIO.write(rec,out,'fasta')
summary={'VEGFA_versioned_transcripts':len(records),'primary_RNA_records':len(allrows),'valid_UTR_transcripts':len(u),'representative_UTR_genes':len(representatives),'annotation_release':'RS_2025_08','assembly':'GCF_000001405.40_GRCh38.p14','freeze_status':'WORKING_NOT_F1_OR_F3_FROZEN','limitations':['Not evidence of actual dominant isoform or APA in ARPE19','Primary reference only for UTR; full RefSeq RNA provided separately for near-perfect search','Length mismatch/partial/short/ambiguous UTR excluded explicitly; lack of annotation is UNKNOWN']}
(O/'reference_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(summary,flush=True)
