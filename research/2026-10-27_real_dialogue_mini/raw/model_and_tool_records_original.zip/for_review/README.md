# 评审阅读入口

先读[项目说明](PROJECT_BRIEFING_ZH.md)，再按下面题卡阅读。全部任务为已见开发材料；不是独立未见测试。所有人工字段空白。参考底表与各答复实际交付严格分开，不给缺证据的回答事后补答案。

- [W1完整题卡](cards/W1.md)
- [W2完整题卡](cards/W2.md)
- [W2b完整题卡](cards/W2b.md)
- [W3完整题卡](cards/W3.md)
- [U1完整题卡](cards/U1.md)
- [R1完整题卡](cards/R1.md)
- [R2完整题卡](cards/R2.md)
- [R3完整题卡](cards/R3.md)
- [R4完整题卡](cards/R4.md)

附件匿名副本只移除明确配置身份字段或报告标题身份，科学数值和回答原文不改；逐文件变化及原/副本指纹见attachment_transformations.json。未改原件保留在执行端完整包。工具过程/文风可能暴露来源，不声称完全盲法。组别密钥、模型原始HTTP与修复讨论不在本包。

score_workbook_payload.json及三个_blank.tsv用于生成编号一致的Excel；执行端回收运行包后用现有官方表格工具生成XLSX并读回检查，再交正式评分。不能把旧33行空表冒充本批匹配表。当前不要填写替身、未运行位置或虚构的人名。
