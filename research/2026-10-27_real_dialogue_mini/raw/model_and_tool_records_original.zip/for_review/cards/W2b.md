# W2b：完整题卡（已见开发材料）

实际用途：准确取得与序列及上下文绑定的已有分数。

类别：work；共同母题：reference_score。多轮题合起来评价一个任务。

## 科研用途、完整问题与判断依据

### W2b：只核对一个分数，N1的标准对照

**完整题干：**
“请核查VEGFA_SD_3499对应的OligoFormer scaled预测分数，给出保留原始精度的数值、来源和与输入序列的对应关系，并说明是否能换算成实际敲低百分比。不做seed、表达或候选排名。”

**原始输入：** C9中VEGFA_SD_3499的完整原始行，guide核心UGUACUACGGAAUAUCUCG，保留原21nt链与其他字段；不预先附分数。

**允许资源与证据：** 同一REF和历史分数绑定表，必要的候选检查→参考核对→分数导入；固定流程score子流程已有。需证明没有仅按ID套用结果。

**判定依据与合理答案：** scaled为0.9915144175887107；可同时显示0.9915，须说明是显示舍入。若附raw_class1则为0.7393843531608582，名称不能混用。不能解释为99.15%实测敲低。普通模型诚实报告无法取得该值，属于边界正确/任务未完成，不属于编造。它是限定范围标准任务，与U1后半段相关，不能仅因另有编号就增加独立题数。



## 原始输入和每轮条件全文

```json
[
  {
    "message": "请核查VEGFA_SD_3499对应的OligoFormer scaled预测分数，给出保留原始精度的数值、来源和与输入序列的对应关系，并说明是否能换算成实际敲低百分比。不做seed、表达或候选排名。",
    "user_input": {
      "candidate_rows": [
        {
          "source_run": "VEGFA_NM003376_6",
          "source_tool": "siDirect_2.0",
          "target_start_1based": "3499",
          "target_end_1based": "3521",
          "target_window_23nt": "TTCGAGATATTCCGTAGTACATA",
          "guide_21nt_RNA_5to3": "UGUACUACGGAAUAUCUCGAA",
          "passenger_21nt_RNA_5to3": "CGAGAUAUUCCGUAGUACAUA",
          "guide_paired_core_19nt_5to3": "UGUACUACGGAAUAUCUCG",
          "passenger_paired_core_19nt_5to3": "CGAGAUAUUCCGUAGUACA",
          "guide_overhang_3prime": "AA",
          "passenger_overhang_3prime": "UA",
          "functional_rule": "U",
          "seed_tm_guide_C": "21.3",
          "seed_tm_passenger_C": "15.9",
          "vendor_min_mismatches_guide_19nt_g2g20": "3",
          "vendor_min_mismatches_passenger_19nt_g2g20": "3",
          "candidate_id": "VEGFA_SD_3499",
          "target_gene": "VEGFA",
          "design_transcript": "NM_003376.6",
          "core_matches_n": "20",
          "core_matches_transcripts": "NM_001171623.2;NM_001171626.2;NM_001171628.2;NM_001317010.2;NM_001025369.3;NM_001171627.2;NM_001171625.2;NM_001204384.2;NM_001287044.2;NM_001025367.3;NM_001171630.2;NM_001171622.2;NM_001171624.2;NM_001025370.3;NM_001204385.2;NM_001025368.3;NM_001033756.3;NM_003376.6;NM_001025366.3;NM_001171629.2",
          "all_20_transcripts_core_match": "True",
          "guide_gc_pct": "42.10526315789474",
          "working_pool_pass": "True",
          "exclusion_reason": "NA",
          "synthesis_status": "NOT_ORDER_READY_MODIFICATIONS_UNFROZEN",
          "oligo_input_derivation": "19_BP_PAIRED_CORE_FROM_VERIFIED_AUTHOR_21NT_DUPLEX_NOT_ARBITRARY_TRUNCATION"
        }
      ]
    },
    "conditions": {
      "candidate_check": false,
      "reference_check": false,
      "score_check": true,
      "seed_check": false,
      "expression_check": false,
      "report_required": false,
      "both_expression_states": false,
      "compare_all_requested_candidates": false,
      "chain_assumption_provided": false,
      "allow_builtin_expression": true
    }
  }
]
```

允许资源见[资源表](../allowed_resources.json)；[事实标准草案](../reference_for_judgement/fact_items_DRAFT.json)和[定位依据](../reference_for_judgement/anchors.json)供判断，不算某份答复实际交付。

## 实际匿名交付

- A013：已尝试，保留各轮原文与失败；[全文](../answers/A013/answer.txt)、[原始输入](../answers/A013/input.json)、[实际过程与证据](../answers/A013/process.json)、[安全阅读页](../answers/A013/answer.html)、[模型原文字段](../answers/A013/raw_model_answer.txt)、[实际附件目录](../answers/A013/attachments/)。
- A019：已尝试，保留各轮原文与失败；[全文](../answers/A019/answer.txt)、[原始输入](../answers/A019/input.json)、[实际过程与证据](../answers/A019/process.json)、[安全阅读页](../answers/A019/answer.html)、[模型原文字段](../answers/A019/raw_model_answer.txt)、[实际附件目录](../answers/A019/attachments/)。
- A024：已尝试，保留各轮原文与失败；[全文](../answers/A024/answer.txt)、[原始输入](../answers/A024/input.json)、[实际过程与证据](../answers/A024/process.json)、[安全阅读页](../answers/A024/answer.html)、[模型原文字段](../answers/A024/raw_model_answer.txt)、[实际附件目录](../answers/A024/attachments/)。

评分位置：评分表按上述答复编号填写四维、交付、严重错误和理由；逐事实表按相同编号逐项核对。空白不是0。完成与必要事实/严重错误矛盾时等待人工核对。不能只按工具数或程序完成状态评分。
