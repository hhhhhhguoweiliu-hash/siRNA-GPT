.libPaths(c('C:/Users/86182/AppData/Local/R/win-library/4.3',.libPaths()))
suppressPackageStartupMessages({library(Biostrings);library(dplyr)})
root <- 'analysis/ARPE19_candidates_20261016'
out <- file.path(root,'risk_raw');dir.create(out,showWarnings=FALSE)
source(file.path(root,'official_tools/SeedMatchR_1.1.1/R/get_seed.R'))
source(file.path(root,'official_tools/SeedMatchR_1.1.1/R/SeedMatchR.R'))
example <- get_seed('UUAUAGAGCAAGAACACUGUUUU','mer7m8')
stopifnot(as.character(example$Target.Seq)=='CTCTATA')
writeLines(capture.output(example),file.path(out,'SeedMatchR_official_get_seed_example.txt'))
writeLines('PASS_OFFICIAL_DOCUMENTED_GET_SEED_EXAMPLE_ONLY_NOT_FULL_PACKAGE',file.path(out,'seed_example.status'))
print('official example passed')
candidates <- read.delim(file.path(root,'prepared/candidates_working_pool.tsv'),check.names=FALSE)
manifest <- read.delim(file.path(root,'prepared/utr_manifest_representative.tsv'),check.names=FALSE)
utrs <- readDNAStringSet(file.path(root,'prepared/refseq_utr3_representative.fasta'))
stopifnot(!anyDuplicated(names(utrs)),!anyDuplicated(manifest$gene_id),all(names(utrs)%in%manifest$transcript_id))
res <- data.frame(gene_id=manifest$gene_id)
gtf <- manifest[,c('transcript_id','gene_id')]
counts <- list();sites <- list();seedrows <- list();k<-0L
for(i in seq_len(nrow(candidates))){
 for(strand in c('guide','passenger')){
  seq <- candidates[[paste0(strand,'_21nt_RNA_5to3')]][i]
  for(seedtype in c('mer7m8','mer8','mer7A1','mer6')){
   z<-SeedMatchR(res=res,gtf=gtf,seqs=utrs,sequence=seq,seed.name=seedtype,mismatches=0,indels=FALSE)
   stopifnot(identical(as.character(z$gene_id),as.character(res$gene_id)))
   z$candidate_id<-candidates$candidate_id[i];z$strand_role<-strand;z$seed_type<-seedtype
   names(z)[names(z)==seedtype]<-'seed_site_count'
   counts[[length(counts)+1L]]<-z
   seed<-get_seed(seq,seedtype)
   seedrows[[length(seedrows)+1L]]<-data.frame(candidate_id=candidates$candidate_id[i],strand_role=strand,seed_type=seedtype,target_motif_5to3=as.character(seed$Target.Seq))
   if(seedtype=='mer7m8'){
    matches<-vmatchPattern(seed$Target.Seq,utrs,fixed=TRUE)
    rr<-as.data.frame(matches)
    if(nrow(rr)){
     rr$transcript_id<-names(utrs)[rr$group];rr$gene_id<-manifest$gene_id[match(rr$transcript_id,manifest$transcript_id)]
     rr$candidate_id<-candidates$candidate_id[i];rr$strand_role<-strand;rr$seed_type<-seedtype;rr$target_motif_5to3<-as.character(seed$Target.Seq)
     rr$coordinate_system<-'1_BASED_IN_REPRESENTATIVE_3UTR'
     sites[[length(sites)+1L]]<-rr
    }
   }
  }
 }
 cat('Seed completed',candidates$candidate_id[i],'\n');flush.console()
}
data.table::fwrite(do.call(rbind,counts),file.path(out,'seed_counts_official.tsv'),sep='\t')
data.table::fwrite(do.call(rbind,sites),file.path(out,'seed_sites_7merm8.tsv'),sep='\t')
data.table::fwrite(do.call(rbind,seedrows),file.path(out,'seed_motifs.tsv'),sep='\t')
writeLines('PASS_OFFICIAL_UNMODIFIED_FUNCTIONS_REPRESENTATIVE_UTR_WORKING_REFERENCE',file.path(out,'seed_scan.status'))
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
print('Loading full RefSeq RNA for independent transparent sequence search')
full<-readDNAStringSet(file.path(root,'prepared/refseq_all_transcripts.fasta'))
stopifnot(!anyDuplicated(names(full)))
near<-list()
for(i in seq_len(nrow(candidates))){
 for(strand in c('guide','passenger')){
  for(kind in c('paired_core19','author_RNA21')){
   seq<-candidates[[if(kind=='paired_core19')paste0(strand,'_paired_core_19nt_5to3') else paste0(strand,'_21nt_RNA_5to3')]][i]
   pattern<-reverseComplement(DNAString(RNAString(seq)))
   hits<-vmatchPattern(pattern,full,max.mismatch=2,with.indels=FALSE,fixed=TRUE)
   rr<-as.data.frame(hits)
   if(nrow(rr)){
    rr$transcript_id<-names(full)[rr$group]
    rr$mismatches<-vapply(seq_len(nrow(rr)),function(k) as.integer(neditStartingAt(pattern,full[[rr$group[k]]],rr$start[k],with.indels=FALSE,fixed=TRUE)),integer(1))
    stopifnot(all(rr$mismatches<=2))
    rr$candidate_id<-candidates$candidate_id[i];rr$strand_role<-strand;rr$query_kind<-kind;rr$query_length_nt<-nchar(seq);rr$coordinate_system<-'1_BASED_IN_REFSEQ_TRANSCRIPT';rr$search_implementation<-'BIOSTRINGS_VMATCHPATTERN_FIXED_HAMMING_NO_INDELS_SUPPLEMENTAL_NOT_SIDIRECT_OR_OLIGOFORMER'
    near[[length(near)+1L]]<-rr
   }
   cat('Near-perfect completed',candidates$candidate_id[i],strand,kind,'hits',nrow(rr),'\n');flush.console()
  }
 }
 data.table::fwrite(do.call(rbind,near),file.path(out,'nearperfect_sites.tsv'),sep='\t')
}
writeLines('PASS_SUPPLEMENTAL_BIOSTRINGS_SEARCH_NOT_AN_EFFICACY_MODEL',file.path(out,'nearperfect.status'))
