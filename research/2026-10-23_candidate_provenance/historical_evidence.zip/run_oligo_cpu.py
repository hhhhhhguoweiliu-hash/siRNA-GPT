"""CPU adapter calling pinned official model/features without editing upstream code.
Changes vs CLI: Python I/O instead of Unix shell; RNA-FM API/raw layer 12 same
token slice as official predictor; eval/no_grad explicitly enabled for inference.
"""
from pathlib import Path
import sys,os,json,hashlib,datetime,random
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'official_tools/OligoFormer/scripts'))
sys.path.insert(0,str(R/'official_tools/RNA-FM/source'))
import torch,numpy as np,pandas as pd
from Bio import SeqIO
from infer import calculate_td,func_filter,antiRNA
from model import Oligo
from loader_infer import sequence_OneHot
import fm
O=R/'oligo_raw';O.mkdir(exist_ok=True)
torch.set_num_threads(2);random.seed(42);np.random.seed(42);torch.manual_seed(42)
torch.use_deterministic_algorithms(True)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
rna_model,alphabet=fm.pretrained.rna_fm_t12(str(R/'official_tools/RNA-FM/RNA-FM_pretrained.pth'))
rna_model=rna_model.cpu().eval();converter=alphabet.get_batch_converter()
model=Oligo(vocab_size=26,embedding_dim=128,lstm_dim=32,n_head=8,n_layers=1,lm1=19,lm2=19).cpu()
state=torch.load(str(R/'official_tools/OligoFormer/model/best_model.pth'),map_location='cpu')
model.load_state_dict(state,strict=True);model.eval()
cache={}
def embedding(seq):
 if seq not in cache:
  _,_,tokens=converter([('RNA',seq)])
  with torch.no_grad():rep=rna_model(tokens,repr_layers=[12],return_contacts=False)['representations'][12][0,1:1+len(seq)].cpu()
  assert tuple(rep.shape)==(len(seq),640) and torch.isfinite(rep).all()
  cache[seq]=rep
  np.save(O/(hashlib.sha256(seq.encode()).hexdigest()+'.npy'),rep.numpy())
 return cache[seq]
def predict(guide,context):
 assert len(guide)==19 and len(context)==57
 td=calculate_td(pd.DataFrame({'siRNA':[guide],'mRNA':[context]})).td.iloc[0]
 si=torch.tensor(sequence_OneHot(list(guide)).T[None,:,:],dtype=torch.float64)
 mr=torch.tensor(sequence_OneHot(list(context)).T[None,:,:],dtype=torch.float64)
 # Original loader emits (batch, 1, length, 5), then RNA-FM (batch,length,640).
 si=si[:,None,:,:];mr=mr[:,None,:,:]
 sf=embedding(guide)[None,:,:];mf=embedding(context)[None,:,:];td=torch.tensor([td],dtype=torch.float32)
 with torch.no_grad():pred,_,_=model(si,mr,sf,mf,td)
 raw=float(pred[:,1].item());assert np.isfinite(raw)
 return raw,raw*1.341,int(func_filter([guide])[0])
def context_for(mrna,guide):
 sense=antiRNA(guide);positions=[i for i in range(len(mrna)-18) if mrna[i:i+19]==sense]
 if not positions:return None
 start=positions[0]
 context='X'*max(0,19-start)+mrna[max(0,start-19):start+38]+'X'*max(0,start+38-len(mrna))
 assert len(context)==57
 return start,context,len(positions)
def run_examples():
 refs=list(SeqIO.parse(R/'official_tools/OligoFormer/data/example.fa','fasta'))
 guides=list(SeqIO.parse(R/'official_tools/OligoFormer/data/example_siRNA.fa','fasta'));rows=[]
 for mr in refs:
  for gr in guides:
   guide=str(gr.seq).upper().replace('T','U');ctx=context_for(str(mr.seq).upper().replace('T','U'),guide)
   if ctx is None:continue
   start,context,matches=ctx;a=predict(guide,context);b=predict(guide,context)
   assert a==b
   rows.append(dict(mrna_id=mr.id,guide_id=gr.id,guide_19nt=guide,context_57nt=context,start_1based=start+1,matching_sites_n=matches,raw_class1=a[0],author_scaled_score=a[1],official_func_filter=a[2],repeat_identical=True))
 assert len(rows)>0
 pd.DataFrame(rows).to_csv(O/'official_example_cpu.tsv',sep='\t',index=False)
 (O/'example.status').write_text('PASS_OFFICIAL_EXAMPLE_INPUTS_OFFICIAL_WEIGHTS_CPU_ADAPTER_WITH_EVAL_REPEATED_IDENTICAL')
 print('Official example passed',len(rows),flush=True)
 return rows
examples=run_examples()
c=pd.read_csv(R/'prepared/candidates_working_pool.tsv',sep='\t');ref=str(SeqIO.read(R/'public_sources/VEGFA_NM003376.gb','genbank').seq).upper().replace('T','U')
rows=[]
for row in c.itertuples():
 guide=row.guide_paired_core_19nt_5to3;start,context,matches=context_for(ref,guide)
 a=predict(guide,context);b=predict(guide,context);assert a==b
 rows.append(dict(candidate_id=row.candidate_id,guide_core19_5to3=guide,design_transcript='NM_003376.6',core_target_start_1based=start+1,mRNA_context_57nt=context,matching_sites_n=matches,raw_class1=a[0],oligoformer_scaled_score=a[1],official_func_filter=a[2],repeat_identical=True,adapter_mode='CPU_EVAL_LAYER12_RAW_OFFICIAL_WEIGHTS',interpretation='MODEL_SCORE_NOT_KNOCKDOWN_PERCENT'))
 pd.DataFrame(rows).to_csv(O/'VEGFA_candidates_cpu.tsv',sep='\t',index=False)
 print(row.candidate_id,a,flush=True)
# Independent adapter check through the official Dataset/DataLoader implementation.
from loader import data_process_loader_infer
qa=O/'official_loader_qa';q=qa/'data/infer/QA'
for role in ['siRNA','mRNA']:(q/role/'representations').mkdir(parents=True,exist_ok=True)
x=examples[0]
for role,seq in [('siRNA',x['guide_19nt']),('mRNA',x['context_57nt'])]:
 (q/(role+'.fa')).write_text('>RNA0\n'+seq+'\n')
 np.save(q/role/'representations/RNA0.npy',embedding(seq).numpy())
df=calculate_td(pd.DataFrame({'siRNA':[x['guide_19nt']],'mRNA':[x['context_57nt']]}))
cwd=os.getcwd()
try:
 os.chdir(qa)
 ds=data_process_loader_infer(df.index.values,df,'QA')
 batch=next(iter(torch.utils.data.DataLoader(ds,batch_size=1,shuffle=False,num_workers=0)))
 with torch.no_grad():out,_,_=model(*batch)
 assert float(out[:,1].item())==x['raw_class1']
finally:os.chdir(cwd)
(O/'official_loader_parity.json').write_text(json.dumps({'status':'PASS','official_loader_class':'loader.data_process_loader_infer','official_example_raw_class1':x['raw_class1'],'official_loader_raw_class1':float(out[:,1].item()),'exact_equality':True,'RNAFM_raw_slice':'layer12, tokens[1:1+sequence_length]','upstream_sources_modified':False},indent=2))
manifest={'started_at':started,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'torch':torch.__version__,'numpy':np.__version__,'pandas':pd.__version__,'device':'cpu','threads':2,'seed':42,'upstream_code_unmodified':True,'compatibility_differences':['Python wrapper instead of Unix shell','Official RNA-FM API and layer12 raw tokens 1:1+length matching official predictor','Explicit eval/no_grad (upstream infer lacks eval) and fixed deterministic CPU','Physical author 21nt duplex retained; score applies only to validated 19bp paired core, no arbitrary input shortening'],'not_tested':['PITA','TargetScan','OligoFormer toxicity','mismatch model'],'score_not_percent':True}
(O/'run_manifest.json').write_text(json.dumps(manifest,indent=2));(O/'candidate.status').write_text('PASS_CPU_ADAPTER_PROVISIONAL_CANDIDATES')
