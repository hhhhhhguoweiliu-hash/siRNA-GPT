from pathlib import Path
import json,urllib.request,hashlib,datetime,concurrent.futures,urllib.parse
ROOT=Path(__file__).resolve().parent; P=ROOT/'public_sources'; T=ROOT/'official_tools';T.mkdir(exist_ok=True)
sha=json.loads((P/'oligo_commit.json').read_text())['sha']
tree=json.loads((P/'oligo_tree.json').read_text())['tree']
items=[]
for f in tree:
 path=f['path']
 if f['type']=='blob' and (path.startswith('scripts/') and not path.endswith('.ipynb') or path in ['model/best_model.pth','model/mismatch_model.pth','data/example.fa','data/example_siRNA.fa','requirements.txt','LICENSE','README.md']):
  items.append((T/'OligoFormer'/path,'https://raw.githubusercontent.com/lulab/OligoFormer/'+sha+'/'+urllib.parse.quote(path)))
items.extend([(P/'rnafm_README.md','https://raw.githubusercontent.com/ml4bio/RNA-FM/main/README.md'),(P/'rnafm_pretrained.py','https://raw.githubusercontent.com/ml4bio/RNA-FM/main/fm/pretrained.py'),(P/'rnafm_commit.json','https://api.github.com/repos/ml4bio/RNA-FM/commits/main')])
def get(item):
 p,url=item;p.parent.mkdir(parents=True,exist_ok=True)
 r={'path':str(p.relative_to(ROOT)),'url':url,'time':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(url,timeout=30) as f: b=f.read()
  p.write_bytes(b);r.update(status='DOWNLOADED',bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r.update(status='FAILED',error=repr(e))
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:rs=list(ex.map(get,items))
(P/'official_tool_sources_manifest.json').write_text(json.dumps(rs,indent=2),encoding='utf-8')
for r in rs:print(r['path'],r['status'],r.get('error',''),flush=True)
