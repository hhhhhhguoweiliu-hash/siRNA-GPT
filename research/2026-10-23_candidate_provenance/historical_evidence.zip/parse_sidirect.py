from pathlib import Path
import sys,re,json
import pandas as pd
R=Path(__file__).resolve().parent;sys.path.append(str(R/'pydeps'))
from bs4 import BeautifulSoup
from Bio import SeqIO
O=R/'prepared';O.mkdir(exist_ok=True)
refs={r.id:str(r.seq).upper() for r in SeqIO.parse(O/'VEGFA_vendor_versions.fasta','fasta')}
rc=lambda s:s.translate(str.maketrans('ACGTU','TGCAA'))[::-1].replace('T','U')
allrows=[];examples=[]
for name in ['official_sample','VEGFA_NM003376_6']:
 soup=BeautifulSoup((R/'sidirect_raw'/f'{name}_response.html').read_bytes(),'html.parser')
 ta=soup.find_all('textarea')
 text='\n'.join(t.get_text() for t in ta)
 rows=[]
 for line in text.splitlines():
  cols=line.strip().split('\t')
  if len(cols)!=9 or not re.fullmatch(r'\d+-\d+',cols[0]):continue
  span,target,guide,passenger,rule,gtm,ptm,gmm,pmm=cols
  start,end=map(int,span.split('-'));target=target.upper();guide=guide.upper();passenger=passenger.upper()
  assert len(target)==23 and len(guide)==len(passenger)==21
  assert guide==rc(target[:21]) and passenger==target[2:].replace('T','U')
  core=guide[:19];sense=passenger[:19]
  assert core==rc(sense) and core==rc(target[2:21])
  row={'source_run':name,'source_tool':'siDirect_2.0','target_start_1based':start,'target_end_1based':end,'target_window_23nt':target,'guide_21nt_RNA_5to3':guide,'passenger_21nt_RNA_5to3':passenger,'guide_paired_core_19nt_5to3':core,'passenger_paired_core_19nt_5to3':sense,'guide_overhang_3prime':guide[19:],'passenger_overhang_3prime':passenger[19:],'functional_rule':rule,'seed_tm_guide_C':float(gtm),'seed_tm_passenger_C':float(ptm),'vendor_min_mismatches_guide_19nt_g2g20':int(gmm),'vendor_min_mismatches_passenger_19nt_g2g20':int(pmm)}
  if name.startswith('VEGFA'):
   assert refs['NM_003376.6'][start-1:end]==target
   core_matches=[tid for tid,seq in refs.items() if sense.replace('U','T') in seq]
   row.update(candidate_id=f'VEGFA_SD_{start:04d}',target_gene='VEGFA',design_transcript='NM_003376.6',core_matches_n=len(core_matches),core_matches_transcripts=';'.join(core_matches),all_20_transcripts_core_match=len(core_matches)==len(refs),guide_gc_pct=100*(core.count('G')+core.count('C'))/19)
   reasons=[]
   if min(int(gmm),int(pmm))<2:reasons.append('SIDIRECT_LEGACY_DATABASE_MIN_MISMATCH_LT2')
   if not 30<=row['guide_gc_pct']<=65:reasons.append('CORE_GC_OUTSIDE_WORKING_30_65')
   if re.search(r'(A{4}|U{4}|C{4}|G{4})',core) or re.search(r'(A{4}|U{4}|C{4}|G{4})',sense):reasons.append('CORE_HOMOPOLYMER_GE4')
   if len(core_matches)!=len(refs):reasons.append('NOT_COMMON_TO_ALL_20_VENDOR_TRANSCRIPT_CORES')
   row.update(working_pool_pass=not reasons,exclusion_reason=';'.join(reasons) or 'NA',synthesis_status='NOT_ORDER_READY_MODIFICATIONS_UNFROZEN',oligo_input_derivation='19_BP_PAIRED_CORE_FROM_VERIFIED_AUTHOR_21NT_DUPLEX_NOT_ARBITRARY_TRUNCATION')
  rows.append(row)
 pd.DataFrame(rows).to_csv(O/f'{name}_parsed.tsv',sep='\t',index=False)
 assert len(rows)>0
 if name=='official_sample':examples=rows
 else:allrows=rows
d=pd.DataFrame(allrows);d.to_csv(O/'candidates_all.tsv',sep='\t',index=False)
passing=d[d.working_pool_pass].drop_duplicates('guide_paired_core_19nt_5to3').copy()
passing.to_csv(O/'candidates_working_pool.tsv',sep='\t',index=False)
with open(O/'candidate_core19_guides.fasta','w') as f:
 for row in passing.itertuples():f.write(f'>{row.candidate_id}\n{row.guide_paired_core_19nt_5to3}\n')
summary={'official_sample_candidates_verified':len(examples),'VEGFA_author_candidates':len(d),'working_pool':len(passing),'all_20_core_coverage':int(d.all_20_transcripts_core_match.sum()),'limitations':['siDirect uses an older unspecified RefSeq database; fresh reference screening remains necessary','Original author 21nt natural overhang duplex preserved; 19bp paired core extracted with complementarity assertions for OligoFormer only','Working filters transparent, not frozen F3 or a learned ranking','No synthetic oligonucleotides ordered; no efficacy or off-target biology claimed']}
(O/'candidate_pool_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(summary)
