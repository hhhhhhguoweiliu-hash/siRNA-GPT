from pathlib import Path
import urllib.request,json,hashlib
R=Path(__file__).resolve().parent;O=R/'official_tools/SeedMatchR_1.1.1';O.mkdir(parents=True,exist_ok=True)
with urllib.request.urlopen('https://api.github.com/repos/cran/SeedMatchR/commits/master',timeout=25) as f:j=json.load(f)
sha=j['sha'];(O/'commit.json').write_text(json.dumps(j,indent=2))
files=['R/get_seed.R','R/SeedMatchR.R','tests/testthat/test-SeedMatchR.R','DESCRIPTION','LICENSE','man/get_seed.Rd','man/SeedMatchR.Rd']
rows=[]
for n in files:
 url=f'https://raw.githubusercontent.com/cran/SeedMatchR/{sha}/{n}';p=O/n;p.parent.mkdir(parents=True,exist_ok=True)
 try:
  with urllib.request.urlopen(url,timeout=20) as f:b=f.read()
  p.write_bytes(b);rows.append({'file':n,'url':url,'sha256':hashlib.sha256(b).hexdigest(),'status':'DOWNLOADED'})
 except Exception as e:rows.append({'file':n,'url':url,'status':'FAILED','error':repr(e)})
(O/'manifest.json').write_text(json.dumps(rows,indent=2))
