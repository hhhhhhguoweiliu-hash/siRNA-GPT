from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parent/'pydeps'))
from bs4 import BeautifulSoup
from Bio import SeqIO
import urllib.request,urllib.parse,json,hashlib,datetime
R=Path(__file__).resolve().parent;P=R/'public_sources';O=R/'sidirect_raw';O.mkdir(exist_ok=True)
html=(P/'sidirect_v2.html').read_text();soup=BeautifulSoup(html,'html.parser');form=soup.find('form',attrs={'name':'siDirect'})
defaults={}
for tag in form.find_all(['input','select','textarea']):
 name=tag.get('name')
 if not name:continue
 if tag.name=='textarea':defaults[name]=tag.text
 elif tag.name=='select':
  opt=tag.find('option',selected=True) or tag.find('option');defaults[name]=opt.get('value',opt.text)
 elif tag.get('type') not in ['submit','button','checkbox','radio'] or tag.has_attr('checked'):defaults[name]=tag.get('value','')
rec=SeqIO.read(P/'VEGFA_NM003376.gb','genbank')
assert rec.id=='NM_003376.6' and rec.annotations.get('organism')=='Homo sapiens'
requests=[('official_sample',defaults['yourSeq']),('VEGFA_NM003376_6',f'>{rec.id}\n{str(rec.seq)}\n')]
manifest=[]
for name,seq in requests:
 params=dict(defaults);params['yourSeq']=seq
 (O/(name+'_request.json')).write_text(json.dumps({'url':'https://sidirect2.rnai.jp/v2.0/design.cgi','parameters':params,'public_sequence_only':True},indent=2),encoding='utf-8')
 row={'run_id':name,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  req=urllib.request.Request('https://sidirect2.rnai.jp/v2.0/design.cgi',data=urllib.parse.urlencode(params).encode(),headers={'User-Agent':'ARPE19-public-reference-design/0.1'})
  with urllib.request.urlopen(req,timeout=50) as f:raw=f.read();row.update(http_status=f.status,final_url=f.url)
  (O/(name+'_response.html')).write_bytes(raw);row.update(status='RESPONSE_RECEIVED_NOT_YET_VALIDATED',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 except Exception as e:row.update(status='FAILED',error=repr(e))
 row['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();manifest.append(row)
 print(row,flush=True)
 (O/'run_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
